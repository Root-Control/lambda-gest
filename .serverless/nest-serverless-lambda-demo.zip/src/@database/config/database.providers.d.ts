export declare const DatabaseProvider: import("@nestjs/common").DynamicModule;
