import { ValidationOptions } from 'class-validator';
export declare function IsSameAt(property: string, validationOptions?: ValidationOptions): (object: object, propertyName: string) => void;
