export declare function Trim(): PropertyDecorator;
export declare function ToBoolean(): PropertyDecorator;
export declare function ToInt(): PropertyDecorator;
export declare function ToArray(): PropertyDecorator;
export declare function ToLowerCase(): PropertyDecorator;
export declare function ToUpperCase(): PropertyDecorator;
export declare function PhoneNumberSerializer(): PropertyDecorator;
