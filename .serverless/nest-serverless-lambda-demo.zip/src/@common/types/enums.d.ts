declare enum Statuslocations {
    NO_GPS = "no-gps",
    NOT_FOUND = "not-found",
    FOUND = "found",
    FOUND_PLUS = "found+"
}
export { Statuslocations };
