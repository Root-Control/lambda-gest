"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Statuslocations = void 0;
var Statuslocations;
(function (Statuslocations) {
    Statuslocations["NO_GPS"] = "no-gps";
    Statuslocations["NOT_FOUND"] = "not-found";
    Statuslocations["FOUND"] = "found";
    Statuslocations["FOUND_PLUS"] = "found+";
})(Statuslocations || (exports.Statuslocations = Statuslocations = {}));
//# sourceMappingURL=enums.js.map