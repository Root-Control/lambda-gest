export declare function extractKey(path: string): string;
