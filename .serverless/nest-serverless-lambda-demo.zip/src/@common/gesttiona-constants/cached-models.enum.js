var CACHED_MODELS;
(function (CACHED_MODELS) {
    CACHED_MODELS["MARK_TYPE"] = "MARK_TYPE";
    CACHED_MODELS["WORKER_DAY"] = "WORKER_DAY";
})(CACHED_MODELS || (CACHED_MODELS = {}));
//# sourceMappingURL=cached-models.enum.js.map