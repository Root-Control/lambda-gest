declare enum MarkTypes {
    START = "start",
    START_LUNCH = "start_lunch",
    END_LUNCH = "end_lunch",
    END = "end",
    CHECKPOINT = "checkpoint"
}
