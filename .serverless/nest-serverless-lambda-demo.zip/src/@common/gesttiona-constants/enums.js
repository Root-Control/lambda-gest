var MarkTypes;
(function (MarkTypes) {
    MarkTypes["START"] = "start";
    MarkTypes["START_LUNCH"] = "start_lunch";
    MarkTypes["END_LUNCH"] = "end_lunch";
    MarkTypes["END"] = "end";
    MarkTypes["CHECKPOINT"] = "checkpoint";
})(MarkTypes || (MarkTypes = {}));
//# sourceMappingURL=enums.js.map