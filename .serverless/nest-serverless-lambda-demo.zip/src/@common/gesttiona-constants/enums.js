"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarkTypes = void 0;
var MarkTypes;
(function (MarkTypes) {
    MarkTypes["START"] = "start";
    MarkTypes["START_LUNCH"] = "start_lunch";
    MarkTypes["END_LUNCH"] = "end_lunch";
    MarkTypes["END"] = "end";
    MarkTypes["CHECKPOINT"] = "checkpoint";
})(MarkTypes || (exports.MarkTypes = MarkTypes = {}));
//# sourceMappingURL=enums.js.map