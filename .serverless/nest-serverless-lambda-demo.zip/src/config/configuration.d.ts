import { IAppConfig } from './configuration.interface';
declare const _default: () => IAppConfig;
export default _default;
