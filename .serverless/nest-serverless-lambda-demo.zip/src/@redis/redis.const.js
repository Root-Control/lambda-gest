"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RedisClientIds = void 0;
var RedisClientIds;
(function (RedisClientIds) {
    RedisClientIds["main"] = "redis_main";
})(RedisClientIds || (exports.RedisClientIds = RedisClientIds = {}));
//# sourceMappingURL=redis.const.js.map