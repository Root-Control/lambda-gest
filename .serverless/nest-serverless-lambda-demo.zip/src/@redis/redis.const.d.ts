export declare enum RedisClientIds {
    main = "redis_main"
}
