export declare class CreateWorkerDayDto {
    date: string;
    shift_id: number;
    user_id: number;
    team_id: number;
    tmpKey: string;
    type: string;
}
