export declare class MarksModule {
}
