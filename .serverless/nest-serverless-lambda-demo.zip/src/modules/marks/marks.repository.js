"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarkRepository = void 0;
const typeorm_1 = require("typeorm");
class MarkRepository extends typeorm_1.Repository {
}
exports.MarkRepository = MarkRepository;
//# sourceMappingURL=marks.repository.js.map