import { User } from '@common/types/express';
export declare class MarkValidator {
    user: User;
    errors: string[];
    constructor(_user: User);
    isValidUser(): this;
    isValidContract(): this;
    workerDayexists(): this;
    verifyUserShift(): this;
    haveJustifiedAssistance(): this;
}
