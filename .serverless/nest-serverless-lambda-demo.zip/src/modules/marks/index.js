"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MarksModule = void 0;
const marks_module_1 = require("./marks.module");
Object.defineProperty(exports, "MarksModule", { enumerable: true, get: function () { return marks_module_1.MarksModule; } });
//# sourceMappingURL=index.js.map