import { MarksModule } from './marks.module';
export { MarksModule };
