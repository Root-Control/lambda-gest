import { Repository } from 'typeorm';
import { Mark } from './mark.model';
export declare class MarkRepository extends Repository<Mark> {
}
