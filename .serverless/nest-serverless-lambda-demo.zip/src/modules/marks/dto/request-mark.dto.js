"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RequestMarkDto = void 0;
const enums_1 = require("@common/types/enums");
const field_decorators_1 = require("../../../@common/decorators/field.decorators");
class RequestMarkDto {
}
exports.RequestMarkDto = RequestMarkDto;
__decorate([
    (0, field_decorators_1.NumberField)(),
    __metadata("design:type", Number)
], RequestMarkDto.prototype, "timeOffline", void 0);
__decorate([
    (0, field_decorators_1.StringField)(),
    __metadata("design:type", String)
], RequestMarkDto.prototype, "date", void 0);
__decorate([
    (0, field_decorators_1.StringField)(),
    __metadata("design:type", String)
], RequestMarkDto.prototype, "time", void 0);
__decorate([
    (0, field_decorators_1.StringField)(),
    __metadata("design:type", String)
], RequestMarkDto.prototype, "mark_type", void 0);
__decorate([
    (0, field_decorators_1.StringFieldOptional)(),
    __metadata("design:type", String)
], RequestMarkDto.prototype, "shift", void 0);
__decorate([
    (0, field_decorators_1.StringField)(),
    __metadata("design:type", String)
], RequestMarkDto.prototype, "img", void 0);
__decorate([
    (0, field_decorators_1.NumberField)(),
    __metadata("design:type", Number)
], RequestMarkDto.prototype, "location", void 0);
__decorate([
    (0, field_decorators_1.EnumField)(() => enums_1.Statuslocations),
    __metadata("design:type", String)
], RequestMarkDto.prototype, "status_location", void 0);
__decorate([
    (0, field_decorators_1.DateField)(),
    __metadata("design:type", String)
], RequestMarkDto.prototype, "realDate", void 0);
__decorate([
    (0, field_decorators_1.StringFieldOptional)({ nullable: true }),
    __metadata("design:type", String)
], RequestMarkDto.prototype, "latitude", void 0);
__decorate([
    (0, field_decorators_1.StringFieldOptional)({ nullable: true }),
    __metadata("design:type", String)
], RequestMarkDto.prototype, "longitude", void 0);
__decorate([
    (0, field_decorators_1.StringFieldOptional)({ nullable: true, minLength: 0 }),
    __metadata("design:type", String)
], RequestMarkDto.prototype, "photo", void 0);
//# sourceMappingURL=request-mark.dto.js.map