export declare class RabbitMqModule {
}
