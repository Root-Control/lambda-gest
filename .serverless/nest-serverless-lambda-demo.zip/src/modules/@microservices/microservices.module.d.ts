export declare class MicroServicesModule {
}
