export declare class AbstractApiModule {
}
