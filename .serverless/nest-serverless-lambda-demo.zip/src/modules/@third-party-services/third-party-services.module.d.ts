export declare class ThirdPartyServicesModule {
}
